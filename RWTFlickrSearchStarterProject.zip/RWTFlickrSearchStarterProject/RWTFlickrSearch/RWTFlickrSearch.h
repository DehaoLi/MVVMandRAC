//
//  RWTFlickrSearch.h
//  RWTFlickrSearch
//
//  Created by sks on 16/6/26.
//  Copyright © 2016年 Colin Eberhardt. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ReactiveCocoa/ReactiveCocoa.h>



//这个协议定义了Model层的初始接口，并将搜索Flickr的责任移出ViewModel。

@protocol RWTFlickrSearch <NSObject>

- (RACSignal *)flickrSearchSignal:(NSString *)searchString;

@end
