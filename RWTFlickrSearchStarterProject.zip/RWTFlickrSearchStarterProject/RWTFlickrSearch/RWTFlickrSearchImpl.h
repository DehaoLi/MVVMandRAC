//
//  RWTFlickrSearchImpl.h
//  RWTFlickrSearch
//
//  Created by sks on 16/6/26.
//  Copyright © 2016年 Colin Eberhardt. All rights reserved.
//

#import <Foundation/Foundation.h>
@import Foundation;
#import "RWTFlickrSearch.h"

@interface RWTFlickrSearchImpl : NSObject<RWTFlickrSearch>

@end
