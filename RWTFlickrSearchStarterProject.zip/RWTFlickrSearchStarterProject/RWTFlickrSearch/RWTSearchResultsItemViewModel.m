//
//  RWTSearchResultsItemViewModel.m
//  RWTFlickrSearch
//
//  Created by sks on 16/6/26.
//  Copyright © 2016年 Colin Eberhardt. All rights reserved.
//

#import "RWTSearchResultsItemViewModel.h"
#import <ReactiveCocoa/ReactiveCocoa.h>
#import <ReactiveCocoa/RACEXTScope.h>
#import "RWTFlickrPhotoMetadata.h"
#import <LinqToObjectiveC/NSArray+LinqExtensions.h>
#import "RWTSearchResultsItemViewModel.h"


@interface RWTSearchResultsItemViewModel ()

@property (weak, nonatomic) id<RWTViewModelServices> services;
@property (strong, nonatomic) RWTFlickrPhoto *photo;

@end

@implementation RWTSearchResultsItemViewModel

- (instancetype)initWithPhoto:(RWTFlickrPhoto *)photo services:(id<RWTViewModelServices>)services {
    self = [super init];
    if (self) {
        _title = photo.title;
        _url = photo.url;
        _services = services;
        _photo = photo;
        
        [self initialize];
    }
    return  self;
}

- (void)initialize {
    RACSignal *fetchMetadata =
    [RACObserve(self, isVisible)
     filter:^BOOL(NSNumber *visible) {
         return [visible boolValue];
     }];
    
//    @weakify(self)
//    [fetchMetadata subscribeNext:^(id x) {
//        @strongify(self)
//        [[[self.services getFlickrSearchService] flickrImageMetadata:self.photo.identifier]
//         subscribeNext:^(RWTFlickrPhotoMetadata *x) {
//             self.favorites = @(x.favorites);
//             self.comments = @(x.comments);
//         }];
//    }];
//    
//    _searchResults =
//    [results.photos linq_select:^id(RWTFlickrPhoto *photo) {
//        return [[RWTSearchResultsItemViewModel alloc]
//                initWithPhoto:photo services:services];
//    }];
}

@end
